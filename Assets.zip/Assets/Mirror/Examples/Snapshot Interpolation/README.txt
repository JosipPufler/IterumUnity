Snapshot Interpolation is a standalone, Unity / netcode independent algorithm.
This is a simple demo to test it, without Mirror.
We want this to be usable in all game engines.